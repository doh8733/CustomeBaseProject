package com.example.customebaseproject.model


import com.google.gson.annotations.SerializedName

class User : ArrayList<UserItem>()