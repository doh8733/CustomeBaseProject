package com.example.customebaseproject

data class Test(var count : Int) {
}