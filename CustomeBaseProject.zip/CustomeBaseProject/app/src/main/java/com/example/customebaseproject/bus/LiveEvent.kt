package com.example.customebaseproject.bus

class LiveEvent {
    //create class BusEvent here

}