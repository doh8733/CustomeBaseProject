package com.example.customebaseproject.base.custom

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.customebaseproject.R

class BaseEndlessRecyclerview : RelativeLayout {
    private val swipeRefresh: SwipeRefreshLayout by lazy { findViewById<SwipeRefreshLayout>(R.id.swipeRefresh) }
    private val rcvEndlessLoading: RecyclerView by lazy { findViewById<RecyclerView>(R.id.rcv_endless_loading) }

    init {
        LayoutInflater.from(context).inflate(R.layout.endless_recyclerview, this, false)
        //set params for view
    }
    constructor(context: Context) : super(context) {
    }

    constructor(context: Context, attrs: AttributeSet) : super(
        context,
        attrs
    ) {
        setUp(attrs)
    }

    constructor(
        context: Context,
        attrs: AttributeSet,
        defStyleAttr: Int
    ) : super(context, attrs, defStyleAttr) {
        setUp(attrs)
    }
    fun setUp(attrs :AttributeSet){
        val a =
            context!!.theme.obtainStyledAttributes(attrs, R.styleable.BaseEndlessRecyclerview, 0, 0)
        val isRefresh =
            a.getBoolean(R.styleable.BaseEndlessRecyclerview_endless_rcv_enable_refresh, true)
        swipeRefresh.isEnabled = isRefresh
    }
    fun setEnableRefresh(isRefresh: Boolean) {
        swipeRefresh.isRefreshing = isRefresh
    }

    fun setOrientationLayout(layoutManager: LayoutManager) {
        rcvEndlessLoading.layoutManager = layoutManager
    }
}