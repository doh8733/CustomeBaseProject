package com.example.customebaseproject


import androidx.activity.viewModels
import com.example.customebaseproject.bus.LiveEvent
import com.example.customebaseproject.databinding.ActivityMainBinding
import com.example.customebaseproject.viewmodel.UserViewModel
import org.greenrobot.eventbus.EventBus

class MainActivity : BaseActivity<ActivityMainBinding>() {
    private val viewModel: UserViewModel by viewModels()
    override val layoutId: ActivityMainBinding
        get() = ActivityMainBinding.inflate(layoutInflater)

    override fun initData() {
    }

    override fun initViews() {
    }

    override fun initListener() {

    }

    override fun initLiveData() {
//        binding.tvText.setOnClickListener {
//            EventBus.getDefault().post(LiveEvent("ahahaha"))
//            goNextActivity(MainActivity2::class.java)
//        }
//        binding.tvText.let {
//
//        }
    }

    override fun <U> getListObjectResponse(list: List<U>?) {
        super.getListObjectResponse(list)
    }


}


