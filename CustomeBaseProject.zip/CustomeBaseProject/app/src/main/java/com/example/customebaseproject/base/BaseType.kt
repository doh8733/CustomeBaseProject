package com.example.customebaseproject.base

enum class BaseType {
    LOADING,SUCCESS,ERROR
}