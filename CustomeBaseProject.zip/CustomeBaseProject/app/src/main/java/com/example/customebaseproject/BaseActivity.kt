package com.example.customebaseproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.annotation.LayoutRes
import androidx.viewbinding.ViewBinding
import com.example.customebaseproject.base.BaseResourceList
import com.example.customebaseproject.base.BaseResourceObject
import com.example.customebaseproject.base.BaseType.*
import com.example.customebaseproject.databinding.ActivityBaseBinding

abstract class BaseActivity<B : ViewBinding>() : AppCompatActivity() {
    lateinit var binding :B
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = layoutId
        setContentView(binding.root)
        initData()
        initViews()
        initListener()
        initLiveData()
    }

    abstract val layoutId: B
    abstract fun initData()
    abstract fun initViews()
    abstract fun initListener()
    abstract fun initLiveData()
    protected fun <T> goNextActivity(activity: Class<T>, bundle: Bundle? = null) {
        val i = Intent(this, activity)
        bundle?.let { i.putExtras(it) }
        startActivity(i)
    }

    protected fun handlerObjectResponse(status: BaseResourceObject<*>) {
        when (status.status) {
            LOADING -> {
                showLoadingDiaLog()
            }
            SUCCESS -> {
                getObjectResponse(status.data)
                hideLoadingDialog()
            }
            ERROR -> {
                handlerObjectErrorResponse<Unit>(status.message)
            }
        }
    }

    protected fun handlerListResponse(status: BaseResourceList<*>) {
        when (status.status) {
            LOADING -> {
                showLoadingDiaLog()
                Toast.makeText(this, "LOADING", Toast.LENGTH_SHORT).show()
            }
            SUCCESS -> {
                getListObjectResponse(status.data)
            }
            ERROR -> {
                handlerListObjectErrorResponse<Unit>(status.message)
            }
        }
    }

    open fun <U> getObjectResponse(data: U) {

    }

    open fun <U> handlerObjectErrorResponse(message: String?) {

    }

    open fun <U> getListObjectResponse(list: List<U>?) {

    }

    open fun <U> handlerListObjectErrorResponse(message: String?) {

    }

    private fun showLoadingDiaLog() {

    }

    private fun hideLoadingDialog() {

    }


}