package com.example.customebaseproject.adapter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.customebaseproject.R
import com.example.customebaseproject.Test
import com.example.customebaseproject.base.adapter.BaseEndlessAdapter

class TestBaseAdapter(context: Context) : BaseEndlessAdapter(context,false){
    class TestBaseViewHolder(view :View) : OnBindViewHolder(view){
        private val textView: TextView by lazy { view.findViewById<TextView>(R.id.textView) }
        fun onBindUi(test: Test){
            textView.text = test.toString()
        }
    }
    override fun initOnCreateViewHolder(parent: ViewGroup): RecyclerView.ViewHolder {
    return TestBaseViewHolder(View.inflate(context.applicationContext, R.layout.layout_test,parent))
    }

    override fun initOnBindViewHolder(holder: OnBindViewHolder, position: Int) {
        val item = getItem(Test::class.java,position)
        item?.let {
            (holder as TestBaseViewHolder).onBindUi(it)
        }
    }
}