package com.example.customebaseproject.base.adapter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

abstract class BaseEndlessAdapter(var context: Context, loadingMore: Boolean) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var listModelWrapper = mutableListOf<Any>()
    var recyclerView: RecyclerView? = null

    fun <T> getItem(model: Class<T>, position: Int): T? = model.cast(listModelWrapper[position])
    fun <T> addModels(listModel : MutableList<T>){
        listModelWrapper.addAll(listOf(listModel))
    }
    fun <T> addModel(listModel: MutableList<T>, form: Int, to: Int) {
        for (i in form..to) {
            val listIndex = mutableListOf(listModel[i])
            addModel(listIndex)
            listIndex.clear()
        }
    }

    fun <T> addModel(listModel: MutableList<T>) {
        listModelWrapper.add(listModel)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return solvedOnCreateViewHolder(parent, viewType)
    }

    override fun getItemCount(): Int {
        return listModelWrapper.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        solvedOnBindViewHolder(holder, position)
    }

    open fun solvedOnCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return initOnCreateViewHolder(parent)
    }

    abstract fun initOnCreateViewHolder(parent: ViewGroup): RecyclerView.ViewHolder

    open fun solvedOnBindViewHolder(holder: ViewHolder, position: Int) {
        initOnBindViewHolder(holder as OnBindViewHolder, position)
    }

    abstract fun initOnBindViewHolder(holder: OnBindViewHolder, position: Int)

    abstract class OnBindViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}