package com.example.customebaseproject

import android.app.Application

class MyApplication :Application() {
    //do something
    override fun onCreate() {
        super.onCreate()
    }
}